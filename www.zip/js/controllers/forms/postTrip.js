angular.module('starter.controllers')
.controller('PostTripCtrl', ['$scope', '$state', '$ionicHistory',
    function($scope, $state, $ionicHistory) {

    
    }
]);